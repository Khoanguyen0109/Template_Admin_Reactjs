import Auth0Service from './auth0Service';

export default Auth0Service;
