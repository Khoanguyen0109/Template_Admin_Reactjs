import React from 'react';

function LeftSideLayout1() {
	return <></>;
}

export default React.memo(LeftSideLayout1);
